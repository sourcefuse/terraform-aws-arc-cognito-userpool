def handler(event, context):
    # Cognito can pass username or email in different places depending on setup
    email = event["userName"]
    if "email" in event.get("request", {}).get("userAttributes", {}):
        email = event["request"]["userAttributes"]["email"]

    # Normalize case
    email = email.lower()

    # Allowed domain
    allowed_domain = "@sourcefuse.com"

    if email.endswith(allowed_domain):
        event["response"] = {"autoConfirmUser": True}
        return event
    else:
        raise Exception(f"Only company email addresses ({allowed_domain}) are allowed to sign up.")